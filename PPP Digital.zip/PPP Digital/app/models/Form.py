from flask_wtf import FlaskForm
from wtforms import String

class buscaBolsa(FlaskForm):
	buscaBolsa = StringField("buscaBolsa")
	