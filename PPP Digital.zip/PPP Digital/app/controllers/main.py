from flask import render_template, url_for, redirect, request, jsonify
from app import app
from app.controllers import auxiliar
import sqlite3

@app.route('/Home', methods=('GET', 'POST'))
@app.route('/', methods=('GET', 'POST'))
def home():
        
	return render_template('index_v1.html')

@app.route('/cotacao', methods=('GET' , 'POST'))
def cotacao():
        #con = sqlite3.connect('../../Base.db')
        #c = con.cursor()
        #for x in c.execute('SELECT * FROM Base_Ativos'):
        #        print(x)
        return render_template('cotacao.html')

@app.route('/cotVisuPrin', methods=('GET', 'POST'))
def cotVisuPrin():
        aux = auxiliar.cotVisuPrin()
        print(aux)
        return jsonify(data=aux)
        
