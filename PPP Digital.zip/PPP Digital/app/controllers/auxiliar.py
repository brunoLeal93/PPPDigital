import sqlite3

def cotVisuPrin():
    conn = sqlite3.connect('../../Base.db')
    cur = conn.cursor()
    vet = []

    for row in cur.execute("SELECT DISTINCT fonte, mercado, tp_instrumento FROM Base_Ativos"):
        
        doc={
		"fonte":row[0],
		"mercado": row[1],
		"tp_instrumento": row[2]
        }

        vet.append(doc)
    return vet

#a= cotVisuPrin()

#print(a[0])
