from openpyxl import load_workbook
import sqlite3




def importaBase():

    con = sqlite3.connect('Base.db')
    c = con.cursor()
    c.execute("CREATE TABLE Base_Ativos (fonte, desc_pag, ticker, desc_ticker, mercado, tp_instrumento)")
    wb = load_workbook('ModelBase2.xlsx')
    sheet = wb['Base_Ativos']
    #print(sheet.cell(column=1, row=1).value)
    row= 2
    #vet = []
    
    while row < 67600:

        #print('{} | ação índice'.format( sheet.cell(column=4, row=row).value ))
        
        #print('{} | {} | {} | {} | {} | {}'.format(sheet.cell(column=1, row=row).value,
        #                                     sheet.cell(column=2, row=row).value,
        #                                     sheet.cell(column=3, row=row).value,
        #                                     type(sheet.cell(column=4, row=row).value),
        #                                     sheet.cell(column=5, row=row).value,
        #                                     sheet.cell(column=6, row=row).value))
        #print(sheet.cell(column=1, row=row).value)
        #print(sheet.cell(column=2, row=row).value)
        #print(sheet.cell(column=3, row=row).value)
        #print(sheet.cell(column=4, row=row).value)
        #print(sheet.cell(column=5, row=row).value)
        #print(sheet.cell(column=6, row=row).value)
                  
        c.execute("INSERT INTO Base_Ativos VALUES (?, ?, ?,?, ?, ?)",(sheet.cell(column=1, row=row).value, sheet.cell(column=2, row=row).value, sheet.cell(column=3, row=row).value,sheet.cell(column=4, row=row).value,sheet.cell(column=5, row=row).value,sheet.cell(column=6, row=row).value))
        con.commit()

        #doc= {
        #        'fonte': sheet.cell(column=1, row=row).value,
        #        'desc_pag':sheet.cell(column=2, row=row).value,
        #        'ticker':sheet.cell(column=3, row=row).value,
        #        'desc_ticker':sheet.cell(column=4, row=row).value,
        #        'mercado':sheet.cell(column=5, row=row).value,
        #        'tp_instrumento':sheet.cell(column=6, row=row).value
        #    }
        row = row +1

        if sheet.cell(column=1, row=row).value == None:
            break

        
        #con.close()

def consultaBase():
    
    con = sqlite3.connect('Base.db')
    c = con.cursor()
    a = 1
    for x in c.execute('SELECT * FROM Base_Ativos'):
        #print(x[1])
        print("Fonte:{}|  Mercado:{}| Tipo Ativo:{}".format(x[0],x[4],x[5]))

        a = a +1

def cotVisuPrin():
    conn = sqlite3.connect('Base.db')
    cur = conn.cursor()
    vet = []

    for row in cur.execute("SELECT DISTINCT fonte, mercado, tp_instrumento FROM Base_Ativos"):
        
        doc={
		"fonte":row[0],
		"mercado": row[1],
		"tp_instrumento": row[2]
        }

        vet.append(doc)
    return vet

#importaBase()
#consultaBase()

a = cotVisuPrin()
print(a[1])
